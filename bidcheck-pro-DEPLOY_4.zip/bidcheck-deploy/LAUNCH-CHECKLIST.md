# 🚀 LAUNCH CHECKLIST — Live in 1 Hour

## ⏱️ MINUTE 0-3 · DEPLOY THE SITE
- [ ] Go to https://vercel.com
- [ ] Sign up (free, Google login is fastest)
- [ ] Click "Add New" → "Project"
- [ ] Drag this entire folder onto the page
- [ ] Click Deploy
- [ ] Copy your live URL (e.g. bidcheckpro.vercel.app)

✅ **Site is live.**

---

## ⏱️ MINUTE 3-15 · STRIPE PAYMENT SETUP
- [ ] Go to https://dashboard.stripe.com
- [ ] Activate your account if you haven't (need bank info to receive money)
- [ ] Click **Payment Links** in left menu
- [ ] Click **+ New Payment Link**

### Create Standard Review:
- [ ] Product name: **BidCheck Pro Standard Review**
- [ ] Price: **$59 USD** (one-time)
- [ ] Description: AI construction quote review report
- [ ] Click **After payment** tab
- [ ] Set: **Redirect to URL** = `https://YOUR-VERCEL-URL.vercel.app?paid=1`
- [ ] Click **Create link**
- [ ] **COPY the link** (looks like `https://buy.stripe.com/abc123`)

### Create Rush Deep Dive:
- [ ] Same as above, but $79 and "Rush Deep Dive"
- [ ] Copy that link too

---

## ⏱️ MINUTE 15-20 · PASTE STRIPE LINKS IN CODE

- [ ] Open `index.html` in Notepad/TextEdit
- [ ] Press Ctrl+F (or Cmd+F)
- [ ] Search for: `YOUR_STANDARD_LINK`
- [ ] You'll see this line:
  ```
  const STRIPE={standard:'https://buy.stripe.com/YOUR_STANDARD_LINK',rush:'https://buy.stripe.com/YOUR_RUSH_LINK'};
  ```
- [ ] Replace `https://buy.stripe.com/YOUR_STANDARD_LINK` with your real Standard link
- [ ] Replace `https://buy.stripe.com/YOUR_RUSH_LINK` with your real Rush link
- [ ] Save the file
- [ ] Go back to Vercel → drag the updated file in → Deploy

✅ **Payments are LIVE. You can now accept money.**

---

## ⏱️ MINUTE 20-25 · TEST IT YOURSELF

- [ ] Open your Vercel URL on your phone
- [ ] Fill out the form with a fake quote
- [ ] Click "Pay & Get My AI Report"
- [ ] Use Stripe test card: 4242 4242 4242 4242 / 12/34 / 123
- [ ] Verify the AI report appears
- [ ] Switch Stripe to **Live mode** (top right of dashboard)

---

## ⏱️ MINUTE 25-60 · GET FIRST CUSTOMERS

Open `social-media-pack.md` and post:

### Now (15 min)
- [ ] Post in 3 local Facebook Groups (homeowner, neighborhood, "for sale" groups)
- [ ] Post on Nextdoor for your zip code
- [ ] Share on your personal Facebook

### Today (30 min)
- [ ] Set up Google Business Profile (free, takes 15 min)
- [ ] Create simple Instagram account if you don't have one
- [ ] Post 1 Instagram caption from the pack

### This week (1 hour total)
- [ ] Run a $20 Facebook ad targeting homeowners 30-65
- [ ] Reach out to 5 real estate agents in your area
- [ ] Post on LinkedIn
- [ ] Make 1 TikTok video

---

## 💰 EXPECTED RESULTS

**Day 1-7:** First 1-3 customers from organic posts ($59-237)
**Week 2-4:** Facebook ads start producing 1-2 customers/day
**Month 2:** Word of mouth + reviews → 5-10/day possible
**Month 3+:** Scale ads, add referral program → 10-50/day potential

---

## 🆘 IF SOMETHING BREAKS

**Vercel showing 404?**
→ Make sure file is named exactly `index.html`, not anything else

**Stripe link not working?**
→ Test in incognito browser. Make sure you switched from Test to Live mode in Stripe

**AI not responding?**
→ Check browser console (F12). Site has fallback content if API fails — customer always gets something

**Payment goes through but no report shown?**
→ Check that Stripe Success URL ends with `?paid=1` exactly

---

## 📞 NEXT 24 HOURS

Once your first customer pays:
1. Take a screenshot of the Stripe notification
2. Post it (no names) on social media: "First paid customer! 🎉"
3. This becomes social proof for the next customers

You're in business. Go.
