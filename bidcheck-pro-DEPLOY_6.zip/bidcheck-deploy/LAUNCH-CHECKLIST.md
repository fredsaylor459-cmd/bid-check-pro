# 🚀 BIDCHECK PRO — LAUNCH CHECKLIST

**📞 Your phone: 1-936-265-0859**
**🌐 Your domain: bid-check-pro.vercel.app**

---

## ⏱️ MINUTE 0-3 · DEPLOY THE SITE

- [ ] Go to https://vercel.com
- [ ] Sign up free (Google login fastest)
- [ ] Click "Add New" → "Project" → "Deploy without Git"
- [ ] **Important:** Name your project `bid-check-pro` so URL becomes `bid-check-pro.vercel.app`
- [ ] Drag this folder onto the page → Deploy
- [ ] Copy your live URL

✅ **Site is live.**

---

## ⏱️ MINUTE 3-18 · STRIPE — 3 PAYMENT LINKS

Go to https://dashboard.stripe.com → **Payment Links** → **+ New**

### Link 1: Quick Check
- Name: **BidCheck Pro Quick Check**
- Price: **$79 USD** (one-time)
- Redirect URL: `https://bid-check-pro.vercel.app?paid=1`
- **COPY the link**

### Link 2: Pro Compare
- Name: **BidCheck Pro Pro Compare**
- Price: **$149 USD** (one-time)
- Redirect URL: `https://bid-check-pro.vercel.app?paid=1`
- **COPY the link**

### Link 3: Premium Deep Dive
- Name: **BidCheck Pro Premium Deep Dive**
- Price: **$359 USD** (one-time)
- Redirect URL: `https://bid-check-pro.vercel.app?paid=1`
- **COPY the link**

---

## ⏱️ MINUTE 18-22 · PASTE STRIPE LINKS

1. Open `index.html` in Notepad
2. Ctrl+F → search: `YOUR_QUICK_LINK`
3. Replace all 3 placeholder links with your real Stripe URLs
4. Save → drag back to Vercel → Deploy again

✅ **Payments LIVE. Charging $79 / $149 / $359.**

---

## ⏱️ MINUTE 22-30 · TEST IT

- [ ] Open https://bid-check-pro.vercel.app on your phone
- [ ] **Test the call button** → should ring 1-936-265-0859
- [ ] **Test the text button** → should open SMS
- [ ] Fill form with test quote
- [ ] Test card: **4242 4242 4242 4242** / 12/34 / 123
- [ ] Verify AI report appears
- [ ] Switch Stripe to **Live mode** when ready

---

## 📞 PHONE EVERYWHERE

**1-936-265-0859** appears in:
- ✅ Top nav bar (always visible on desktop)
- ✅ Hero section (Call + Text buttons)
- ✅ Banner above pricing
- ✅ Banner above quote form
- ✅ Footer (Call + Text)

All tap-to-call and tap-to-text.

---

## ⏱️ MINUTE 30-60 · GET CUSTOMERS

### NOW (15 min)
- [ ] Post in 3 local Facebook Groups (include phone!)
- [ ] Post on Nextdoor with phone
- [ ] Personal Facebook share

### TODAY
- [ ] Google Business Profile (free) — add phone 1-936-265-0859
- [ ] 1 Instagram caption

### THIS WEEK
- [ ] $20 Facebook ad with click-to-call
- [ ] DM 5 real estate agents
- [ ] LinkedIn post
- [ ] 1 TikTok video

---

## 💰 REVENUE

| Customers/Day | Monthly |
|---------------|---------|
| 1 | ~$4,500 |
| 3 | ~$13,500 |
| 5 | ~$22,500 |
| 10 | ~$45,000 |

**Premium customers ($359) = biggest wins.**
Target homeowners with $30k+ projects.

---

## 📞 PHONE STRATEGY

Customers WILL call/text first. Be ready:

**Common questions:**
- "How accurate is the AI?" → "30 sec review using Claude AI, trained on thousands of contracts. Want to try?"
- "Really $79?" → "For small repairs yes. Bigger projects $149 or $359."
- "When do I get the report?" → "Instantly after payment."

**Voicemail script:**
"Hi, you've reached BidCheck Pro. We review construction quotes with AI in 30 seconds — visit bid-check-pro.vercel.app or text this number. Leave a message and we'll call back today!"

---

## 🆘 TROUBLESHOOTING

**Vercel 404?** → File must be named `index.html`

**Stripe broken?** → Test in incognito. Live mode on?

**Call button no work?** → It uses `tel:+19362650859` (already correct in code)

**No report after pay?** → Success URL must end with `?paid=1`

---

## 🎯 AFTER FIRST CUSTOMER

1. Screenshot Stripe notification (hide names)
2. Post: "First paying customer! 🎉"
3. Social proof = next customers

**Go.**

📞 1-936-265-0859
🌐 bid-check-pro.vercel.app
