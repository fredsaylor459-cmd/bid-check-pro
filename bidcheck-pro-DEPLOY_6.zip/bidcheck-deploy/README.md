# 🚀 BIDCHECK PRO — Updated Pricing

## ✨ NEW 3-TIER PRICING

| Tier | Price | For |
|------|-------|-----|
| **Quick Check** | $79 | Small repairs · simple quotes |
| **Pro Compare** ⭐ | $149 | Mid projects · most popular |
| **Premium Deep Dive** 🔥 | $359 | Major builds · additions · new construction |

**Average order: ~$150** | **Premium tier saves customers $5k-$20k+**

---

## 🚀 ONE-BUTTON DEPLOY

1. Go to **vercel.com** → Sign up free
2. Click **"Add New" → "Project" → "Deploy without Git"**
3. **Drag this folder** onto the page
4. Click **Deploy**
5. ✅ Live in 60 seconds

---

## 💰 STRIPE SETUP (10 min)

Create 3 Payment Links at https://dashboard.stripe.com:

- **Quick Check** — $79 USD
- **Pro Compare** — $149 USD
- **Premium Deep Dive** — $359 USD

Set Success URL on all 3: `https://YOUR-URL.vercel.app?paid=1`

Paste links in `index.html`:
```
const STRIPE={
  quick:'YOUR_QUICK_LINK',
  pro:'YOUR_PRO_LINK',
  premium:'YOUR_PREMIUM_LINK'
};
```

Re-deploy → DONE.

---

## 🧠 BUILT-IN FEATURES

✅ **AI Quote Analyzer** — Claude AI · 30 sec reviews
✅ **24 Construction Trades** — all of construction
✅ **17 Countries · 12 Currencies** — global
✅ **3-Tier Pricing** — Quick / Pro / Premium
✅ **Stripe Payment Gate** — pay → instant AI report
✅ **AI Auto-Recommendation** — suggests right tier by project size
✅ **CEO AI Assistant** — chat · dashboard · social · marketing
✅ **Premium Counter-Offer** — AI gives target price + milestones (Premium tier)
✅ **Social Share Built-In**

---

## 📁 FILES IN THIS FOLDER

- `index.html` — Your live site (this is the only file you really need)
- `vercel.json` — Vercel config (auto-detected)
- `LAUNCH-CHECKLIST.md` — Step-by-step launch
- `social-media-pack.md` — Ready-to-post content

Open `LAUNCH-CHECKLIST.md` to start.
